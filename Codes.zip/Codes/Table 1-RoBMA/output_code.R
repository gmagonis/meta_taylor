library(RoBMA)

data=read.table("C:/Users/gmago/Documents/output.txt",header=T)

fit <- RoBMA(d=data$d, se=data$se, priors_effect=NULL, priors_heterogeneity=NULL, priors_bias=NULL,priors_effect_null=prior("spike", parameters=list(location = 0)),priors_heterogeneity_null=prior("spike", parameters=list(location = 0)),priors_bias_null=prior_none(),seed = 1)

summary(fit, type = "models")


### adding Model 2: 
fit <- update(fit, priors_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias = prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))

### adding Model 3: 
fit <- update(fit, priors_effect_null = prior("spike", parameters = list(location = 0)),prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias = prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.10))))

### adding Model 4
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))

### adding Model 5
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.025, 0.05))))

### adding Model 6
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.5))))


### adding Model 7
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1, 1), steps = c(0.025, 0.05,0.5))))

          
### adding Model 8
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_PET("Cauchy", parameters = list(0, 1),  truncation = list(lower = 0)))

              
### adding Model 9
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity_null = prior("spike", parameters = list(location = 0)), prior_bias = prior_PEESE("Cauchy", parameters = list(0, 5),  truncation = list(lower = 0)))


#######################################################################################################################################################
### adding Model 10: 
fit <- update(fit, priors_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias_null = prior_none())


### adding Model 11: 
fit <- update(fit, priors_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))


### adding Model 12: 
fit <- update(fit, priors_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.10))))


### adding Model 13
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))
 
             
### adding Model 14
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.025, 0.05))))


### adding Model 15
fit <- update(fit, prior_effect_null= prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.5))))


### adding Model 16
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1, 1), steps = c(0.025, 0.05,0.5))))

              
### adding Model 17
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_PET("Cauchy", parameters = list(0, 1),  truncation = list(lower = 0)))
    
          
### adding Model 18
fit <- update(fit, prior_effect_null = prior("spike", parameters = list(location = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias= prior_PEESE("Cauchy", parameters = list(0, 5),  truncation = list(lower = 0)))


#######################################################################################################################################################

### adding Model 19: 
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias_null = prior_none())


### adding Model 20: 
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias = prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))


### adding Model 21: 
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias=prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.10))))


### adding Model 22
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)),prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias=prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))
 
             
### adding Model 23
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.025, 0.05))))


### adding Model 24
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias=prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.5))))


### adding Model 25
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)),prior_bias= prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1, 1), steps = c(0.025, 0.05,0.5))))

              
### adding Model 26
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias = prior_PET("Cauchy", parameters = list(0, 1),  truncation = list(lower = 0)))

              
### adding Model 27
fit <- update(fit, prior_effect= prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity_null = prior("spike",  parameters = list(location = 0)), prior_bias= prior_PEESE("Cauchy", parameters = list(0, 5),  truncation = list(lower = 0)))


#######################################################################################################################################################
### adding Model 28
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias_null= prior_none())


### adding Model 29: 
fit <- update(fit, prior_effect= prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias=prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))


### adding Model 30: 
fit <- update(fit,prior_effect=prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)),prior_bias=prior_weightfunction("two.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.10))))


### adding Model 31
fit <- update(fit,prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)),prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1), steps = c(0.05))))
 
             
### adding Model 32
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.025, 0.05))))


### adding Model 33
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1), steps = c(0.05, 0.5))))


### adding Model 34
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)),prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)),prior_bias = prior_weightfunction("one.sided", parameters = list(alpha = c(1, 1, 1, 1), steps = c(0.025, 0.05,0.5))))

              
### adding Model 35
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_PET("Cauchy", parameters = list(0, 1),  truncation = list(lower = 0)))
   
           
### adding Model 36
fit <- update(fit, prior_effect = prior("normal", parameters = list(mean = 0.5, sd = .10), truncation = list(lower = 0)), prior_heterogeneity = prior("invgamma", parameters = list(shape = 1, scale = .15)), prior_bias = prior_PEESE("Cauchy", parameters = list(0, 5),  truncation = list(lower = 0)))



summary(fit, type = "models")

summary(fit)