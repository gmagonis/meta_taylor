*CODE FOR FREQUENTIST MODEL AVERAGING

library(foreign)
library(xtable)
library(LowRankQP)

mydata <- read.dta("inflation1_old.dta", convert.dates=TRUE, convert.factors=TRUE, 
           missing.type=TRUE, convert.underscore=TRUE, warn.missing.labels=TRUE)

x.data <- mydata[,-1]
x <- sapply(1:ncol(x.data),function(i){x.data[,i]/max(x.data[,i])})   
scale.vector <- as.matrix(sapply(1:ncol(x.data),function(i){max(x.data[,i])}))        
Y <- as.matrix(mydata[,1])
output.colnames <- colnames(x.data)
full.fit <- lm(Y~x-1)
beta.full <- as.matrix(coef(full.fit))
M <- k <- ncol(x)
n <- nrow(x)
beta <- matrix(0,k,M)
e <- matrix(0,n,M)
K_vector <- matrix(c(1:M))
var.matrix <- matrix(0,k,M)
bias.sq <- matrix(0,k,M)        

for(i in 1:M)
           {
            X <- as.matrix(x[,1:i])
            ortho <- eigen(t(X)%*%X)
            Q <- ortho$vectors ; lambda <- ortho$values 
            x.tilda <- X%*%Q%*%(diag(lambda^-0.5,i,i))
            beta.star <- t(x.tilda)%*%Y
            beta.hat <- Q%*%diag(lambda^-0.5,i,i)%*%beta.star
            beta[1:i,i] <- beta.hat
            e[,i] <- Y-x.tilda%*%as.matrix(beta.star)
            bias.sq[,i] <- (beta[,i]-beta.full)^2
            var.matrix.star <- diag(as.numeric(((t(e[,i])%*%e[,i])/(n-i))),i,i)
            var.matrix.hat <- var.matrix.star%*%(Q%*%diag(lambda^-1,i,i)%*%t(Q))
            var.matrix[1:i,i] <- diag(var.matrix.hat)
            var.matrix[,i] <- var.matrix[,i]+ bias.sq[,i]
            } # End loop over i

             e_k <- e[,M]
             sigma_hat <- as.numeric((t(e_k)%*%e_k)/(n-M))
             G <- t(e)%*%e
             a <- ((sigma_hat)^2)*K_vector
             A <- matrix(1,1,M)
             b <- matrix(1,1,1)
             u <- matrix(1,M,1)
             optim <- LowRankQP(Vmat=G,dvec=a,Amat=A,bvec=b,uvec=u,method="LU",verbose=FALSE)
             weights <- as.matrix(optim$alpha)
             beta.scaled <- beta%*%weights
             final.beta <- beta.scaled/scale.vector
             std.scaled <- sqrt(var.matrix)%*%weights
             final.std <- std.scaled/scale.vector
             results.reduced <- as.matrix(cbind(final.beta,final.std))
             rownames(results.reduced) <- output.colnames; colnames(results.reduced) <- c("Coefficient", "Sd. Err")
             MMA.fls <- round(results.reduced,4)
             
MMA.fls <- data.frame(MMA.fls)
t <- as.data.frame(MMA.fls$Coefficient/MMA.fls$Sd..Err)

